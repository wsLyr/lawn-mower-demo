import { Vec3, _decorator } from "cc";
const { ccclass, property } = _decorator;

@ccclass("VCamHardLook")
export class VCamHardLook {

}