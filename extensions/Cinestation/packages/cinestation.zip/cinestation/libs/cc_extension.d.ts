declare const CC_EDITOR: boolean;
declare const CC_DEBUG: boolean;
declare const cc_JSB: boolean;
declare const cce: any;